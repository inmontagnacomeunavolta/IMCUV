# In Montagna Come una Volta

Sito del gruppo — nessun account Claude richiesto per chi lo visita, una volta pubblicato.

## Contenuto della cartella

- `index.html` — l'intero sito (una pagina sola: testo, grafica e font, tutto incluso)

Le foto e i video delle gite non sono nel sito: ogni gita rimanda a un album Google Photos condiviso.

## Parte 1 — Pubblicare su GitHub Pages (gratis)

1. Vai su github.com/new col tuo account e crea un repository pubblico (es. in-montagna-come-una-volta).
2. Nella pagina del repository, clicca "uploading an existing file" (o Add file -> Upload files).
3. Trascina dentro index.html e clicca Commit changes.
4. Vai su Settings -> Pages.
5. In Branch seleziona main, cartella /root, poi Save.
6. Dopo un paio di minuti, in cima alla stessa pagina compare il link pubblico, tipo:
   https://<tuo-username>.github.io/<nome-repository>/

A questo punto il sito e' gia' online con quel link.

## Parte 2 — Collegare il dominio inmontagnacomeunavolta.it

1. Sempre su Settings -> Pages, nel campo Custom domain scrivi www.inmontagnacomeunavolta.it e clicca Save.
   (GitHub crea da solo un file CNAME nel repository, non serve farlo a mano.)
2. Vai sul pannello di gestione DNS di Register.it (di solito "Gestione DNS" o "Zone DNS" dentro il pannello del tuo dominio).
3. Aggiungi questi record:

   Tipo   | Nome/Host   | Valore
   -------|-------------|------------------------
   CNAME  | www         | <tuo-username>.github.io
   A      | @ (o vuoto) | 185.199.108.153
   A      | @ (o vuoto) | 185.199.109.153
   A      | @ (o vuoto) | 185.199.110.153
   A      | @ (o vuoto) | 185.199.111.153

   (Se Register.it obbliga a un solo record A per riga, aggiungine 4 righe separate, stesso nome "@", un IP ciascuna.)
4. Salva. Il DNS puo' metterci fino a 24 ore per propagarsi (di solito molto meno).
5. Torna su GitHub -> Settings -> Pages: quando il dominio risulta verificato, spunta Enforce HTTPS.

Da quel momento, sia www.inmontagnacomeunavolta.it sia inmontagnacomeunavolta.it apriranno il sito.

## Come aggiornarlo con nuove gite

Torna qui in chat con Claude, mandami i dettagli della nuova gita (data, percorso, chi c'era, link all'album foto), aggiorno index.html e te lo ridò pronto da ricaricare su GitHub (sovrascrivendo il file esistente con "Add file -> Upload files" — il dominio e le impostazioni Pages restano quelli già configurati, non si toccano).
